class methodoverloading

{
	static void test() {
		System.out.println("I am in test()");
	}

	static void test(int x) {
		System.out.println("I am in test(int x)");
	}

	static void test(double x) {
		System.out.println("I am in test(double x)..");
	}

	{
		public static void main(string[]args)
		System.out.println("***************");
		test();
		test(5);
		test(5.5);
		System.out.println("***************");
		}

}
