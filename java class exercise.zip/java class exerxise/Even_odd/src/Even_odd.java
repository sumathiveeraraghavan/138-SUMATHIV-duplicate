
public class Even_odd {

	public static void main(String[] args) {
		{
			int a=8;
			if(a%2==0)
			{
				System.out.println("EVEN NUM="+a);
			}
			else	
			{
				System.out.println("Odd NUM="+a);
			}
			
			
		}

	}

}
