
public class Program2 {

	public static void main(String[] args) {
		System.out.println("***********");
//declaration and intialization
		int x = 10;
		System.out.println("x value=" + x);
		x = 100;
		System.out.println("x value=" + x);
		final double PI = 3.14;
		System.out.println("pi value=" +PI);
		double PI = 6.14;
		System.out.println("pi value=" +PI);
		System.out.println("***********");
	}

}
