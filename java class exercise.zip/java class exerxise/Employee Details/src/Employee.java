
public class Employee {

	public static void main(String[] args) {
		System.out.println("******");
		// variable declaration
		int empid;
		String empname;
		double empsalary;
		float yoe;
		long mobileno;
//variable initialization
		empid = 1234;
		empname = "SUMATHI";
		empsalary = 500000;
		yoe = 3.5f;
		mobileno = 9566914035l;
//variable utilization
		System.out.println("Emp id=" + empid);
		System.out.println("Emp name=" + empname);
		System.out.println("Emp SALARY=" + empsalary);
		System.out.println("YOE=" + yoe);
		System.out.println("Mob no=" + mobileno);
		System.out.println("***********");

	}

}
